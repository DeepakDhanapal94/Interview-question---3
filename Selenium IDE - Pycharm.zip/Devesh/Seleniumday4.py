import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

driver = webdriver.Chrome()
driver.get("https://testautomationpractice.blogspot.com/")
driver.maximize_window()
driver.implicitly_wait(5)
frame1=driver.find_element(By.XPATH,"//iframe[@id='frame-one796456169']")
#driver.switch_to.frame(frame1)
driver.find_element(By.ID,"name").send_keys("Deepak")
time.sleep(2)

#Automation Radio buttons

driver.find_element(By.XPATH,"//label[text()='Male']").click()
time.sleep(2)
driver.find_element(By.XPATH,"//input[@id='RESULT_TextField-2']").send_keys("01/19/2024")
time.sleep(2)
select=Select(driver.find_element(By.XPATH,"//select[@id='RESULT_RadioButton-3']"))
select.select_by_visible_text("Manager")
time.sleep(5)

#From any frame to any frame if you want to come to page then you need to use default content.

driver.switch_to.default_content()
driver.find_element(By.XPATH,"//input[@id='Wikipedia1_wikipedia-search-input']").send_keys("Sachin")
time.sleep(3)
driver.find_element(By.XPATH,"//input[@class='wikipedia-search-button']").click()
time.sleep(5)
results=driver.find_elements(By.XPATH,"//div[@id='Wikipedia1_wikipedia-search-results']/div")
for i in results:
    print (i.text)
driver.find_element(By.XPATH,"//div[@id='Wikipedia1_wikipedia-search-results']/div[2]/a").click()
time.sleep(10)