import time
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

driver = webdriver.Chrome()
driver.get("https://demo.automationtesting.in/Windows.html")
driver.maximize_window()
driver.implicitly_wait(5)

#creating the object of Actions class
action=ActionChains(driver)
interactions=driver.find_element(By.XPATH,"//a[text()='Interactions ']")
draganddrop=driver.find_element(By.XPATH,"//a[text()='Drag and Drop ']")
static=driver.find_element(By.XPATH,"//a[text()='Static ']")
time.sleep(3)

#action class will work when you use perform() method of Actions class.
action.move_to_element(interactions).perform()
time.sleep(3)
action.move_to_element(draganddrop).perform()
time.sleep(3)
static.click()
time.sleep(3)
driver.get("https://testautomationpractice.blogspot.com/")
doubleclickbutton=driver.find_element(By.XPATH,"//button[text()='Copy Text']")
action.double_click(doubleclickbutton).perform()
print (driver.find_element(By.XPATH,"//input[@id='field1']").get_attribute("value"))
time.sleep(2)
drag=driver.find_element(By.XPATH,"//div[@id='draggable']")
drop=driver.find_element(By.XPATH,"//div[@id='droppable']")
action.drag_and_drop(drag,drop).perform()
time.sleep(3)
slider=driver.find_element(By.XPATH,"//div[@id='slider']")
action.click_and_hold(slider).move_by_offset(5,0).release().perform()
time.sleep(10)
resizable=driver.find_element(By.XPATH,"//div[@id='resizable']")
action.click_and_hold(resizable).move_by_offset(5,0).release().perform()
time.sleep(10)




'''
class ActionChains:
    def drag_and_drop(ele1,ele2):
    
    def move_to_element(webelemt):
    
    def double_click(webelement):
    
    def context_click(webelement):
    
action = ActionChains(driver)
action.move_to_element(ele)
action.double_click(ele)
action.context_click(ele)
action.drag_and_drop(el1,el2)
'''

