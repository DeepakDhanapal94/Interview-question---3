from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time

#web table automation

#service_obj = Service("C://Users//admin//Desktop//chromedriver.exe")
#driver = webdriver.Chrome(service=service_obj)
driver = webdriver.Chrome()
driver.get("https://testautomationpractice.blogspot.com/")
driver.maximize_window()
driver.implicitly_wait(5)
webtable=driver.find_element(By.XPATH,"//h2[text()='Web Table']")


#javascript code for scrolling to view the page
driver.execute_script("arguments[0].scrollIntoView()",webtable)
time.sleep(3)
print (driver.find_element(By.XPATH,"//table[@name='BookTable']/tbody/tr[2]/td[3]").text)
print (driver.find_element(By.XPATH,"//table[@name='BookTable']/tbody/tr[4]/td[2]").text)
row=driver.find_elements(By.XPATH,"//table[@name='BookTable']/tbody/tr[4]/td")
for i in row:
    print (i.text, end=" ")
rows=driver.find_elements(By.XPATH,"//table[@name='BookTable']/tbody/tr")
print (len(rows))
row=len(rows) #7
list1=[]
#iterate from 2 row till 7th row
for i in range(2,row+1):
        d={}
        a=driver.find_element(By.XPATH,"//table[@name='BookTable']/tbody/tr["+str(i)+"]/td[4]")
        list1.append(a.text)
print (list1)
list2=[]
for i in range(2,row+1):
    for j in range(1,5):
        b=driver.find_element(By.XPATH,"//table[@name='BookTable']/tbody/tr["+str(i)+"]/td["+str(j)+"]")
        list2.append(b.text)
print (list2)



