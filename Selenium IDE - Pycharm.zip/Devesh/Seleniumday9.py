import openpyxl
import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
service_obj=Service("C://Users//admin//Desktop//chromedriver.exe")
from selenium.webdriver.common.by import By
#driver=webdriver.Chrome("C://Users//admin//Desktop//chromedriver.exe")
driver=webdriver.Chrome(service=service_obj)
driver.get("https://demo.automationtesting.in/Windows.html")
driver.maximize_window()
assert "USER REGISTERATION" in driver.title
# ---------- Reading data from Excel ----------------------------------
'''
workbook=openpyxl.load_workbook("E://Book2.xlsx")
sheet=workbook.get_sheet_by_name("Sheet3")
#name=sheet.cell(3,1).value
#phonenumber=sheet.cell(3,2).value
#email= sheet.cell(4,1).value
#driver.find_element(By.XPATH,"//input[@id='name']").send_keys(name)
#time.sleep(2)
#driver.find_element(By.XPATH,"//input[@id='ph_no']").send_keys(phonenumber)
#time.sleep(2)
#driver.find_element(By.XPATH,"//input[@id='email']").send_keys(email)
#time.sleep(2)
rows=sheet.max_row  #total rows that are filled
colm=sheet.max_column ##total columns that are filled
for r in range(1,rows+1):
    for c in range(1,colm+1):
        name=sheet.cell(r,1).value
        phonenumber=sheet.cell(r,2).value
        driver.find_element(By.XPATH, "//input[@id='name']").clear()
        driver.find_element(By.XPATH, "//input[@id='name']").send_keys(name)
        driver.find_element(By.XPATH, "//input[@id='ph_no']").clear()
        driver.find_element(By.XPATH, "//input[@id='ph_no']").send_keys(phonenumber)
        for r in range(1,rows+1):
        for c in range(1,colm+1):
            print ((sheet.cell(r,c).value), end="  ")
        print ()
'''
#------------------- Writing data to excel ---------------------------
workbook=openpyxl.load_workbook("E://Book2.xlsx")
sheet=workbook.get_sheet_by_name("Sheet4")
sheet.cell(1,1).value="Everyone"
sheet.cell(1,2).value="Hello"
sheet.cell(1,3).value=None
a1=sheet.cell(2,1).value=100
a2=sheet.cell(2,2).value=500
a3=a1+a2
sheet.cell(2,3).value = a3
print (a3)
for r in range(1,5):
    for c in range(1,4):
        sheet.cell(r,c).value="Python classes"
workbook.save("E://Book2.xlsx")
'''
print (sheet.max_row)
print (sheet.max_column)
rows=sheet.max_row
column=sheet.max_column
workbook.save("F://SampleInfo.xlsx")
for r in range(1,rows+1):
    for c in range(1,column+1):
        sheet.cell(r,c).value="hello everyone"
workbook.save("F://SampleInfo.xlsx")
'''









