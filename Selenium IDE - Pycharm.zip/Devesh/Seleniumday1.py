import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

#service_obj= Service("C://Users//admin//Desktop//chromedriver.exe")
#driver = webdriver.Chrome(service=service_obj)


driver = webdriver.Chrome()
driver.get("https://indianfrro.gov.in/frro/FormC/accom_reg.jsp?t4g=0XL36X0J")
driver.maximize_window()
print (driver.current_url)
print (driver.title) #title
assert "User Registration Page" in driver.title #assert is for validation weather you are in current page or not

#driver.back()
time.sleep(2)

#driver.forward()
time.sleep(2)

driver.refresh()

driver.find_element(By.XPATH,"//input[@name='u_id']").send_keys("Deepak123445")
#driver.find_element(By.ID,"name").send_keys("Mohana")
#driver.find_element(By.NAME,"name").send_keys("Jitha")
#driver.find_element(By.CSS_SELECTOR,"#name").send_keys("Pramod")
time.sleep(2)

#ph_no=1237323123
#driver.find_element(By.XPATH,"//input[@id='ph_no']").send_keys(ph_no)
#time.sleep(2)

#password
driver.find_element(By.XPATH,"//input[@name='u_pwd']").send_keys("abc123")
time.sleep(2)

#confirm password
driver.find_element(By.XPATH,"//input[@name='u_repwd']").send_keys("abc123")
time.sleep(2)

#Your Answer
driver.find_element(By.XPATH,"(//input[@class='fieldboxes'])[4]").send_keys("Hi How r u")
time.sleep(2)


#name
driver.find_element(By.XPATH,"//input[@name='u_name']").send_keys("Deepak Dhanapal")

#Designation
driver.find_element(By.XPATH,"//input[@name='u_designation']").send_keys("Team Lead")

#Email_ID
driver.find_element(By.XPATH,"//input[@name='u_emailid']").send_keys("deepakdhanapal94@gmail.com")

#Mobile
driver.find_element(By.XPATH,"//input[@name='u_mobile']").send_keys("7708346311")

#Phone number
driver.find_element(By.XPATH,"//input[@name='u_phone']").send_keys("7708346311")

#Fieldboxes
driver.find_element(By.XPATH, "//input[@class='fieldboxes']").send_keys("Deepak Dhanapal")

#Capacity
driver.find_element(By.XPATH, "//input[@name='capacity']").send_keys("50")

#Address - Getting issue in this line. Unable to get actual input.
driver.find_element(By.XPATH,"(//textarea[@class='fieldboxes'])").send_keys("29, NRK Puram, 3rd street, Tiruppur")

text = driver.find_element(By.XPATH, "//font[text()='If you forget your password we will identify you with this information']")

print(text.is_displayed())
print(text.is_enabled())
print(text.is_selected())

#Security Question - Dropdown Automation
# In Select class you will be having multiple Method:-
#   select_by_visible_text()
#   select_by_index()
#   select_by_value()
select =  Select( driver.find_element(By.XPATH, "//select[@name='u_secques']"))
select.select_by_index(2)

#state
select =  Select( driver.find_element(By.ID, "state"))
select.select_by_visible_text("ANDAMAN AND NICOBAR ISLANDS")
time.sleep(5000)


'''
#locators: 8
name
id = 'name'
class = 
tag_name
link_text = 
partial_link_text
xpath = //input[@id='name']
css_selector =#.

#methods:
driver.get()
'''