import time
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By

driver = webdriver.Chrome() #open chrome browser

driver.get("https://www.amazon.in/")

time.sleep(5)

#driver.find_element(By.NAME,"field-keywords").send_keys("mobile", Keys.ENTER)

driver.find_element(By.XPATH,"(//input[@class='nav-input nav-progressive-attribute'])[1]").send_keys("mobile", Keys.ENTER)

