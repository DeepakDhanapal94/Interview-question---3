
#Alert automation

import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
#service_obj= Service("C://Users//admin//Desktop//chromedriver.exe")
#driver = webdriver.Chrome(service=service_obj)

driver = webdriver.Chrome()
driver.get("https://testautomationpractice.blogspot.com/")
driver.maximize_window()
driver.implicitly_wait(5)
alert1=driver.find_element(By.XPATH,"//button[text()='Simple Alert']")
alert1.click()
switchalert=driver.switch_to.alert
time.sleep(3)
switchalert.accept()

alert2=driver.find_element(By.XPATH,"//button[text()='Confirmation Alert']")
alert2.click()
time.sleep(3)
switchalert.dismiss()


alert3=driver.find_element(By.XPATH,"//button[text()='Prompt Alert']")
alert3.click()
time.sleep(3)
switchalert.send_keys("Deepak")

alert1 = switchalert.text
print(alert1)

time.sleep(5)
switchalert.accept()
time.sleep(5)
