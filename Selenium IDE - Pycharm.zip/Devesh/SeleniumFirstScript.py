from selenium import webdriver
from selenium.webdriver.chrome.service import Service

#Selenium 4.3
#service_obj = Service("D://4Achievers_Python_With_Selenium//SeleniumPythonProject//chromedriver-win64//chromedriver-win64//chromedriver.exe")
#driver = webdriver.Chrome(service = service_obj)

driver = webdriver.Chrome()

driver.get("https://www.amazon.com")





