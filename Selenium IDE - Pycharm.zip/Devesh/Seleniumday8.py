from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.support.select import Select
service_obj = Service("C://Users//admin//Desktop//chromedriver.exe")
driver = webdriver.Chrome(service=service_obj)
driver.get("https://demo.automationtesting.in/Datepicker.html")
driver.maximize_window()
driver.implicitly_wait(5)
driver.find_element(By.XPATH,"//input[@id='datepicker2']").click()
time.sleep(3)
selectmonth=Select(driver.find_element(By.XPATH,"//select[@title='Change the month']"))
for i in selectmonth.options:
    if i.text == "January":
#driver.find_element(By.XPATH,"//input[@id='datepicker2']/following::div[@class='datepick-popup']/div/div[1]/following::table[1]/tbody/tr[3]/td[6]").click()
#time.sleep(5)
        alldaterows=driver.find_elements(By.XPATH,"//input[@id='datepicker2']/following::div[@class='datepick-popup']/div/div[1]/following::table[1]/tbody/tr")
        alldateslen=len(alldaterows)
        alldatecolumns=driver.find_elements(By.XPATH,"//input[@id='datepicker2']/following::div[@class='datepick-popup']/div/div[1]/following::table[1]/tbody/tr[2]/td")
        alldateslencols=len(alldatecolumns)
        for i in range(1,alldateslen):
            for j in range(2,alldateslencols):
                    b = driver.find_element(By.XPATH,"//input[@id='datepicker2']/following::div[@class='datepick-popup']/div/div[1]/following::table[1]/tbody/tr[" + str(i) + "]/td[" + str(j) + "]")
                    if b.text == "15":
                        b.click()
                    else:
                        break
    else:
        break
else:
    pass

