import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

#window automation

driver = webdriver.Chrome()
driver.get("https://testautomationpractice.blogspot.com/")
driver.maximize_window()
driver.implicitly_wait(5)
driver.find_element(By.XPATH,"//input[@id='Wikipedia1_wikipedia-search-input']").send_keys("Selenium")
driver.find_element(By.XPATH,"//input[@class='wikipedia-search-button']").click()
time.sleep(3)
results=driver.find_elements(By.XPATH,"//div[@id='Wikipedia1_wikipedia-search-results']/div")
for i in results:
    print (i.text)

#Click on the listed link

driver.find_element(By.XPATH,"//div[@id='Wikipedia1_wikipedia-search-results']/div[1]/a").click()
time.sleep(3)
windowhandle = driver.window_handles
print(windowhandle)
print(type(windowhandle))
driver.switch_to.window(windowhandle[1])
time.sleep(3)
assert "Selenium" in driver.title
print("title verified for child window")
time.sleep(3)
driver.close()
driver.switch_to.window(windowhandle[0])
assert "Automation Testing Practice" in driver.title
print ("title verified for parent window")
time.sleep(3)


#Multi window handling
driver.get("https://demo.automationtesting.in/Windows.html")
driver.find_element(By.XPATH,"//a[text()='Open Seperate Multiple Windows']").click()
driver.find_element(By.XPATH,"//button[@onclick='multiwindow()']").click()
mutiple_windowhandle=driver.window_handles
print (mutiple_windowhandle)
time.sleep(5)

#Skip signin

driver.switch_to.window(mutiple_windowhandle[2])
driver.find_element(By.XPATH,"//button[text()='Skip Sign In']").click()
print (driver.title)
driver.close()
time.sleep(3)
driver.switch_to.window(mutiple_windowhandle[1])
print (driver.title)
driver.close()
driver.switch_to.window(mutiple_windowhandle[0])
print (driver.title)
driver.close()





