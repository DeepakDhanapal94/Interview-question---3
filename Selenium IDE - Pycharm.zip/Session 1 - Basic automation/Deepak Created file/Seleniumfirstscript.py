#from datetime import time
#from _pydatetime import time
import time

from selenium import webdriver

from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

#If Selenium <4.6
#from selenium.webdriver.chrome.service import Service

#If Selenium 4.6
#service_obj = Service("D://4Achievers_Python_With_Selenium//SeleniumPythonProject//chromedriver-win64//chromedriver-win64//chromedriver.exe")
#driver = webdriver.Chrome(service = service_obj)

#The option to make sure the Chrome browser is open always. Making the webdriver and opening it.
"""chrome_options = Options()
chrome_options.add_experimental_option("detach",True)
driver = webdriver.Chrome(options=chrome_options)"""

driver = webdriver.Chrome() #open Chrome browser

driver.get("https://www.amazon.in")
time.sleep(5)
driver.find_element(By.NAME,"field-keywords").send_keys("mobile", Keys.ENTER)
driver.find_element(By.NAME,"field-keywords").clear()
driver.find_element(By.ID,"twotabsearchtextbox").send_keys("Dress",Keys.ENTER)
driver.find_element(By.ID,"twotabsearchtextbox").clear()
driver.find_element(By.XPATH,"(//input[@class='nav-input nav-progressive-attribute'])[1]").send_keys("shoes", Keys.ENTER)