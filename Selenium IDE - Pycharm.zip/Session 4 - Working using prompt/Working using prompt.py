
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import service
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://testautomationpractice.blogspot.com/")

driver.maximize_window()
driver.implicitly_wait(5)
alert1=driver.find_element(By.XPATH,"//button[text()='Simple Alert']")
alert1.click()
switchalert = driver.switch_to.alert
time.sleep(3)
switchalert.accept()

driver.implicitly_wait(5)
alert2=driver.find_element(By.XPATH, "//button[@id='confirmBtn']")
alert2.click()
time.sleep(3)
switchalert.dismiss()

driver.implicitly_wait(5)
alert3=driver.find_element(By.XPATH,"//button[@id='promptBtn']")
alert3.click()
time.sleep(3)
switchalert.send_keys("Deepak")

alert1 = switchalert.text
print(alert1)

time.sleep(5)
switchalert.accept()
time.sleep(5)

