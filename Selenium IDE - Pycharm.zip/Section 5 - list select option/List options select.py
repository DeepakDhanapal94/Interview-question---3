import time
from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

driver = webdriver.Chrome()
driver.get("https://demo.automationtesting.in/Register.html")

driver.maximize_window() # maximizing the window
driver.implicitly_wait(5) # this wait is applicable for all the web elements

driver.find_element(By.XPATH, "//input[@ng-model='FirstName']").send_keys("Deepak")
driver.find_element(By.XPATH, "//input[@ng-model='LastName']").send_keys("Dhanapal")
driver.find_element(By.XPATH, "//textarea[@ng-model='Adress']").send_keys("NRK puram, 3rd street, Tiruppur - 641607")
driver.find_element(By.XPATH, "//input[@ng-model='EmailAdress']").send_keys("deepakdhanapal94@gmail.com")
driver.find_element(By.XPATH, "//input[@ng-model='Phone']").send_keys("+91-7708346311")
driver.find_element(By.XPATH, "//input[@value='Male']").click()
driver.find_element(By.XPATH,"//input[@value='Cricket']").click()
driver.find_element(By.XPATH,"//div[@id='msdd']").click()
time.sleep(3)

# iterating the list of all the element values

listoptions=driver.find_elements(By.XPATH,"//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all']")
for i in listoptions:
    print(i.text)
    if "English" in i.text:
        driver.find_element(By.XPATH, "//li[@class='ng-scope']").click()
    else:
        pass
time.sleep(5)

select1= Select(driver.find_element(By.XPATH,"//select[@id='Skills']"))
select1.select_by_value("Android")
time.sleep(4)

select=Select(driver.find_element(By.XPATH,"//select[@id='country']"))
for i in select.options:
    if "Japan" in i.text:
        select.select_by_visible_text(i.text)
    else:
        pass
time.sleep(5)