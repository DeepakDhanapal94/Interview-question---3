import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
#service_obj= Service("C://Users//admin//Desktop//chromedriver.exe")
#driver = webdriver.Chrome(service=service_obj)


driver = webdriver.Chrome()
driver.get("https://indianfrro.gov.in/frro/FormC/accom_reg.jsp?t4g=0XL36X0J")
driver.maximize_window()
print (driver.current_url)
print (driver.title) #title
assert "User Registration Page" in driver.title #assert is for validation weather you are in current page or not

#driver.back()
time.sleep(2)

#driver.forward()
time.sleep(2)

driver.refresh()

driver.find_element(By.XPATH,"//input[@name='u_id']").send_keys("Deepak123445")
#driver.find_element(By.ID,"name").send_keys("Mohana")
#driver.find_element(By.NAME,"name").send_keys("Jitha")
#driver.find_element(By.CSS_SELECTOR,"#name").send_keys("Pramod")
time.sleep(2)

#ph_no=1237323123
#driver.find_element(By.XPATH,"//input[@id='ph_no']").send_keys(ph_no)
#time.sleep(2)

#password
driver.find_element(By.XPATH,"//input[@name='u_pwd']").send_keys("abc123")
time.sleep(2)

#confirm password
driver.find_element(By.XPATH,"//input[@name='u_repwd']").send_keys("abc123")
time.sleep(2)

#Your Answer
driver.find_element(By.XPATH,"(//input[@class='fieldboxes'])[4]").send_keys("Hi How r u")
time.sleep(2)

'''
driver.find_element(By.XPATH,"//input[@value='Employed']").click()
time.sleep(2)
driver.find_element(By.XPATH,"//input[@id='CORE_JAVA']").click()
driver.find_element(By.XPATH,"//input[@id='SPRING']").click()
time.sleep(3)
driver.find_element(By.XPATH,"//input[@id='date']").send_keys("10th January")
driver.find_element(By.XPATH,"//input[@id='time']").send_keys("10 AM")
driver.find_element(By.XPATH,"//textarea[@id='desc']").send_keys("Intretsed to join python class")
#driver.find_element(By.XPATH,"//input[@name='Submit']").click()
#driver.find_element(By.LINK_TEXT,"Academic Projects").click()
time.sleep(2)
aboutus_link =driver.find_element(By.XPATH,"/html/body/table/tbody/tr/td/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table[1]/tbody/tr/td[1]/table/tbody/tr[1]/td/table/tbody/tr[2]/td/a")
print (aboutus_link.text)
driver.find_element(By.XPATH,"//a[text()='Academic Projects']").click()
time.sleep(3)

'''

'''
#locators: 8
name
id = 'name'
class = 
tag_name
link_text = 
partial_link_text
xpath = //input[@id='name']
css_selector =#.

#methods:
driver.get()
'''