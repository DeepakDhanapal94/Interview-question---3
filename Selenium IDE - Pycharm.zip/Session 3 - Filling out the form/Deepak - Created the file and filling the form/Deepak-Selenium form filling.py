import time
#from xml.etree.ElementPath import xpath_tokenizer

from selenium import webdriver
from selenium.webdriver.chrome.service import service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

driver = webdriver.Chrome()
time.sleep(5)
driver.get("https://indianfrro.gov.in/frro/FormC/accom_reg.jsp?t4g=0XL36X0J")
driver.maximize_window()
print (driver.current_url)
print (driver.title) #title

assert "User Registration Page" in driver.title #Assert is for validation whether the page is correct or not.

#driver.back()
#time.sleep(2)

#driver.forward()
#time.sleep(2)

driver.refresh()

#username
driver.find_element(By.XPATH, "//input[@name='u_id']").send_keys("Deepak123445")
time.sleep(2)

#password
driver.find_element(By.XPATH,"//input[@name='u_pwd']").send_keys("abc123")
time.sleep(2)

#reconfirm password
driver.find_element(By.XPATH,"//input[@name='u_repwd']").send_keys("abc123")
time.sleep(2)

text = driver.find_element(By.XPATH, "//font[text()='If you forget your password we will identify you with this information']")

print(text.is_displayed())
print(text.is_enabled())
print(text.is_selected())
time.sleep(2)

#Security question
security = Select(driver.find_element(By.ID,"u_secques"))
security.select_by_visible_text("What is the name of the street where you grew up?")
time.sleep(2)

#Security question answer
driver.find_element(By.XPATH,"//input[@name='u_secans']").send_keys("My pet name is Jimmy")
time.sleep(2)

#name
driver.find_element(By.XPATH,"//input[@name='u_name']").send_keys("Deepak Dhanapal")
time.sleep(2)

#Security Question - Dropdown Automation
# In Select class you will be having multiple Method:-
#   select_by_visible_text()
#   select_by_index()
#   select_by_value()


#select = select(driver.find_element(By.XPATH,"//select[@id='u_secques']"))
#select_by_visible_text(" What is the name of the hospital where you were born?")
#print(select.is_displayed())
#select1 =  select( driver.find_element(By.XPATH, "//select[@name='u_secques']"))
#select1.select_by_index(3)
#print(select1.is_selected())

#Gender
gender = Select(driver.find_element(By.ID, "u_gender"))
gender.select_by_visible_text("Male")
time.sleep(1)
#print(gender.is_selected())

#Designation
driver.find_element(By.XPATH,"//input[@name='u_designation']").send_keys("Team Lead")
time.sleep(1)

#Email_ID
driver.find_element(By.XPATH,"//input[@name='u_emailid']").send_keys("deepakdhanapal94@gmail.com")
time.sleep(1)

#Mobile
driver.find_element(By.XPATH,"//input[@name='u_mobile']").send_keys("7708346311")
time.sleep(1)

#Phone number
driver.find_element(By.XPATH,"//input[@name='u_phone']").send_keys("7708346311")
time.sleep(1)

#Nationality
nationality = Select(driver.find_element(By.ID,"u_nationality"))
nationality.select_by_visible_text("AFGHANISTAN")
time.sleep(1)

#Validating the text is displayed
text = driver.find_element(By.XPATH, "//font[text()='Hotel / Guest House / Dharamshala / Institute / Individual House etc. Details']")

print(text.is_displayed())
print(text.is_enabled())
print(text.is_selected())
time.sleep(1)

#Name Fieldboxes
driver.find_element(By.XPATH, "(//input[@class='fieldboxes'])[11]").send_keys("Deepak Dhanapal")
time.sleep(1)

#Capacity
driver.find_element(By.XPATH, "//input[@name='capacity']").send_keys("50")
time.sleep(1)

#Address
driver.find_element(By.XPATH,"(//textarea[@class='fieldboxes'])").send_keys("29, NRK Puram, 3rd street, Tiruppur")
time.sleep(1)

#state
select =  Select( driver.find_element(By.ID, "state"))
select.select_by_visible_text("ANDAMAN AND NICOBAR ISLANDS")
time.sleep(1)

#city
select =  Select( driver.find_element(By.ID, "city_distr"))
select.select_by_visible_text("Select")
time.sleep(1)

#Accomodation type
select =  Select( driver.find_element(By.ID, "acco_type"))
select.select_by_visible_text("Hotel")
time.sleep(1)

#Accomodation grade
select =  Select( driver.find_element(By.ID, "star_rat"))
select.select_by_visible_text("Five Star")
time.sleep(1)

#Email Fieldboxes
driver.find_element(By.XPATH, "(//input[@class='fieldboxes'])[13]").send_keys("deepakdhanapal93@gmail.com")
time.sleep(1)

#Mobile Fieldboxes
driver.find_element(By.XPATH, "(//input[@class='fieldboxes'])[14]").send_keys("7708346322")
time.sleep(1)

#Phone Fieldboxes
driver.find_element(By.XPATH, "(//input[@class='fieldboxes'])[15]").send_keys("7708346333")
time.sleep(1)

#Name

driver.find_element(By.XPATH,"//input[@name='name_o']").send_keys("Deepak Dhanapal")
time.sleep(1)

#Address

driver.find_element(By.XPATH,"//input[@name='address_o']").send_keys("29, NRK Puram, 3rd street, Tiruppur")
time.sleep(1)

#State
select =  Select( driver.find_element(By.ID, "state_o"))
select.select_by_visible_text("ANDAMAN AND NICOBAR ISLANDS")
time.sleep(1)

#City
#select =  Select( driver.find_element(By.XPATH, "(//input[@class='style16'])"))
#select.select_by_visible_text("Select")
#time.sleep(1)

#Email
driver.find_element(By.XPATH, "(//input[@class='fieldboxes'])[18]").send_keys("deepakdhanapal93@gmail.com")
time.sleep(1)

#Phone
driver.find_element(By.XPATH, "(//input[@class='fieldboxes'])[19]").send_keys("7708346333")
time.sleep(1)

#Mobile
driver.find_element(By.XPATH, "(//input[@class='fieldboxes'])[20]").send_keys("7708346322")
time.sleep(1)









