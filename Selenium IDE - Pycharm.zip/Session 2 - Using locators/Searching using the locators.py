import time
from argparse import Action
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver import ActionChains

driver = webdriver.Chrome() #open chrome browser

#driver.get("https://www.amazon.in/")

driver.get("https://www.flipkart.com/")

driver.maximize_window()
driver.implicitly_wait(5)

#driver.find_element(By.NAME,"field-keywords").send_keys("mobile", Keys.ENTER)

#driver.find_element(By.XPATH,"(//input[@class='nav-input nav-progressive-attribute'])[1]").send_keys("mobile", Keys.ENTER)

driver.find_element(By.XPATH,"(//input[@class='Pke_EE'])").send_keys("mobile", Keys.ENTER)

time.sleep(3)

#driver.find_element(By.XPATH,"//input[@class='hm-icon nav-sprite']").click()


#Creating the object of Action class
action=ActionChains(driver)
hover = driver.find_element(By.XPATH, "//span[text()='Electronics']")
time.sleep(3)

#Action class will work when we use perform() method in the action classes
action.move_to_element(hover).perform()

mobile = driver.find_element(By.XPATH, "//a[text()='Mobiles']")
mobile.click()
time.sleep(3)


